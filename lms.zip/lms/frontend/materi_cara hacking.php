<?php
// File Materi: cara hacking
// Deskripsi: haloha
// Video: <iframe width="560" height="315" src="https://www.youtube.com/embed/rIfrJt57sGg" frameborder="0" allowfullscreen></iframe>
// Text: haloha
// Instruksi: haloha
// Thumbnail: 1638.jpg
// Materi PDF: surat panggilan.pdf
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars("cara hacking"); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Add your custom styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 20px;
            font-size: 28px;
            color: #333;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }

        p {
            margin-bottom: 10px;
            font-size: 16px;
            line-height: 1.6;
        }

        strong {
            font-weight: bold;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .thumbnail-container {
            margin-top: 20px;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .thumbnail {
            display: block;
            width: 100%;
            height: auto;
            transition: transform 0.3s;
        }

        .thumbnail:hover {
            transform: scale(1.05);
        }

        .material-link {
            display: block;
            margin-top: 10px;
            font-size: 16px;
        }

        .material-link i {
            margin-right: 5px;
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars("$courseName"); ?></title>
    <link rel="stylesheet" href="materi.css"> <!-- Tautan ke file CSS -->
</head>
<body>
    <h1>cara hacking</h1>
    <p><strong>Deskripsi:</strong> haloha</p>
    <p><strong>Video:</strong><a href="<iframe width="560" height="315" src="https://www.youtube.com/embed/rIfrJt57sGg" frameborder="0" allowfullscreen></iframe></a><iframe width="560" height="315" src="https://www.youtube.com/embed/rIfrJt57sGg" frameborder="0" allowfullscreen></iframe></p>
    <p><strong>Penjelasan:</strong> haloha</p>
    <p><strong>Instruksi:</strong> haloha</p>
    <p><strong>Thumbnail:</strong> <img src="thumbnails/1638.jpg" alt="Thumbnail"></p>
    <p><strong>Materi PDF:</strong> <a href="assets/pdf/surat panggilan.pdf">surat panggilan.pdf</a></p>
</body>
</html>

<?php
// File Materi: cara hacking
// Deskripsi: haloha
// Video: <iframe width="560" height="315" src="https://www.youtube.com/embed/rIfrJt57sGg" frameborder="0" allowfullscreen></iframe>
// Text: haloha
// Instruksi: haloha
// Thumbnail: 1638.jpg
// Materi PDF: surat panggilan.pdf
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars("cara hacking"); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Add your custom styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 20px;
            font-size: 28px;
            color: #333;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }

        p {
            margin-bottom: 10px;
            font-size: 16px;
            line-height: 1.6;
        }

        strong {
            font-weight: bold;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .thumbnail-container {
            margin-top: 20px;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .thumbnail {
            display: block;
            width: 100%;
            height: auto;
            transition: transform 0.3s;
        }

        .thumbnail:hover {
            transform: scale(1.05);
        }

        .material-link {
            display: block;
            margin-top: 10px;
            font-size: 16px;
        }

        .material-link i {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <h1>cara hacking</h1>
    <p><strong>Deskripsi:</strong> haloha</p>
    <p><strong>Video:</strong> <iframe width="560" height="315" src="https://www.youtube.com/embed/rIfrJt57sGg" frameborder="0" allowfullscreen></iframe></p>
    <p><strong>Text:</strong> haloha</p>
    <p><strong>Instruksi:</strong> haloha</p>
    <p><strong>Thumbnail:</strong> <img src="thumbnails/1638.jpg" alt="Thumbnail"></p>
    <p><strong>Materi PDF:</strong> <a href="assets/pdf/surat panggilan.pdf">surat panggilan.pdf</a></p>
</body>
</html>